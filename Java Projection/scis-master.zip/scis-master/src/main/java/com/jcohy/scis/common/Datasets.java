package com.jcohy.scis.common;

import java.util.List;

/**
 * Created by jiac on 2018/5/26.
 * ClassName  : com.jcohy.scis.common
 * Description  :
 */
public class Datasets {

    private List<Data> data ;

    public void setData(List<Data> data){
        this.data = data;
    }
    public List<Data> getData(){
        return this.data;
    }


}
