



ALTER TABLE `project` ADD   `create_date` varchar(50) NULL DEFAULT NULL COMMENT '创建时间';

ALTER TABLE `project` ADD   `update_date` varchar(50) NULL DEFAULT NULL COMMENT '更新时间';