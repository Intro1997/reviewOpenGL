

ALTER TABLE `circular` CHANGE  `start`  `start` varchar(50) NULL DEFAULT NULL COMMENT '开始时间';

ALTER TABLE `circular` CHANGE  `end`  `end` varchar(50) NULL DEFAULT NULL COMMENT '结束时间';

ALTER TABLE `circular` CHANGE  `create_date`  `create_date` varchar(50) NULL DEFAULT NULL COMMENT '开始时间';

ALTER TABLE `circular` CHANGE  `update_date`  `update_date` varchar(50) NULL DEFAULT NULL COMMENT '开始时间';
