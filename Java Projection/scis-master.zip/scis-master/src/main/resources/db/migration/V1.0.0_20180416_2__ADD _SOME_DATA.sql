

INSERT INTO `dept` VALUES ('2', '2001', '机械制造', '小倩', '12345678944', '机械制造学院');
INSERT INTO `dept` VALUES ('3', '3001', '人文', '小段', '12345678944', '人文学院');

INSERT INTO `major` VALUES ('3', '100103', '网络工程', '12345678944', '小胡', '1');
INSERT INTO `major` VALUES ('4', '100104', '物联网', '12345678944', '小倩', '1');
INSERT INTO `major` VALUES ('5', '200101', '机械制造', '12345678944', '小花', '2');
INSERT INTO `major` VALUES ('6', '200102', '数控技术', '12345678944', '小资', '2');
INSERT INTO `major` VALUES ('7', '200103', '铸造技术', '12345678944', '小南', '2');
INSERT INTO `major` VALUES ('8', '300101', '中国语言文学', '12345678944', 'GodV', '3');
INSERT INTO `major` VALUES ('9', '300102', '语言学及应用语言学', '12345678944', '小朱', '3');
INSERT INTO `major` VALUES ('10', '300103', '汉语言文字学', '12345678944', '笑笑', '3');