



alter table `project` drop column `a_status`,drop column `a_reason`;