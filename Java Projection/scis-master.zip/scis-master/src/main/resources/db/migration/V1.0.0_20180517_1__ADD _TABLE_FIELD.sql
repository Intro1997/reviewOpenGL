

ALTER TABLE `circular` ADD  `target_url` VARCHAR (255) NOT NULL DEFAULT '' COMMENT '跳转url';
