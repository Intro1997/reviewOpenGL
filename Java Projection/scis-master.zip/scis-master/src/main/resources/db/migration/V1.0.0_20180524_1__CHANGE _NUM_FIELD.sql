

ALTER TABLE `student` CHANGE  `num`  `num` int(22) NOT NULL;

ALTER TABLE `expert` CHANGE  `num`  `num` int(22) NOT NULL;

ALTER TABLE `teacher` CHANGE  `num`  `num` int(22) NOT NULL;

ALTER TABLE `admin` CHANGE  `num`  `num` int(22) NOT NULL;
