



ALTER TABLE `project` ADD   `genre` varchar(255) NULL DEFAULT NULL COMMENT '个人/团体';

ALTER TABLE `project` ADD   `groups` varchar(255) NULL DEFAULT NULL COMMENT '团体参赛人编号';
