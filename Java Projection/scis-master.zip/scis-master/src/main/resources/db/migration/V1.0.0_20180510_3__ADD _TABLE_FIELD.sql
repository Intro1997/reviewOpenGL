

ALTER TABLE `notice` ADD  `level` int(11) NULL DEFAULT '1';
